import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

class Main
{
	public static void main(String [] args)
	{
	
		String inline;
		try {
			BufferedReader read = new BufferedReader(new FileReader("sample.txt"));
			String line = "";
			while((line = read.readLine())!= null)
			{
				    inline = "";
					URL url = new URL("https://www.quandl.com/api/v3/datasets/NSE/"+line+".json?api_key=VYpxRfPNGWfpxovPnEYT&collapse=weekly&start_date=2018-02-21");
					
					
					HttpURLConnection conn = (HttpURLConnection)url.openConnection();
					
					conn.setRequestMethod("GET");
				
					conn.connect();
				
					int responsecode = conn.getResponseCode();
					System.out.println("");
					System.out.println("Response code is: " +responsecode);
					
				
					if(responsecode != 200)
						throw new RuntimeException("HttpResponseCode: " +responsecode);
					else
					{
					
						Scanner sc = new Scanner(url.openStream());
						while(sc.hasNext())
						{
							inline=inline+"\n"+sc.nextLine();
						}
						System.out.println("\nJSON Response in String format for the company:"+line); 
						System.out.println(inline);
					
						sc.close();
					}
					
				
					//Disconnect the HttpURLConnection stream
					conn.disconnect();
			}
		} catch (Exception e1) {}
	}
}